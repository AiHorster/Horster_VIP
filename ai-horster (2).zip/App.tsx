import React from 'react';
import { TrendingUp, Target, Lock } from 'lucide-react';
import { PainPoints } from './components/PainPoints';
import { PricingCard } from './components/PricingCard';
import { Disclaimer } from './components/Disclaimer';
import { STRIPE_PAYMENT_LINK } from './constants';
import { Button } from './components/Button';

const App: React.FC = () => {
  return (
    <div className="min-h-screen bg-dark-900 text-gray-100 font-sans selection:bg-yellow-500/30">
      
      {/* Navbar */}
      <nav className="fixed w-full z-50 bg-dark-900/90 backdrop-blur-md border-b border-white/5">
        <div className="max-w-6xl mx-auto px-4 py-4 flex justify-between items-center">
          <div className="flex items-center gap-3">
            {/* Logo Image - Please ensure 'logo.jpg' exists in your root folder */}
            <img 
              src="./logo.jpg" 
              alt="Ai-Horster Logo" 
              className="w-10 h-10 rounded-lg border border-yellow-500/20 object-cover shadow-lg shadow-yellow-500/10"
              onError={(e) => {
                e.currentTarget.style.display = 'none';
                e.currentTarget.nextElementSibling?.classList.remove('hidden');
              }}
            />
            <span className="font-bold text-xl tracking-tight text-white">Ai-Horster</span>
          </div>
          <a href={STRIPE_PAYMENT_LINK} target="_blank" rel="noopener noreferrer" 
             className="text-sm font-bold bg-yellow-500 text-black px-4 py-2 rounded-lg hover:bg-yellow-400 transition-colors">
            立即入會
          </a>
        </div>
      </nav>

      {/* Hero Section */}
      <header className="relative pt-32 pb-20 px-4 overflow-hidden">
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full max-w-3xl h-[500px] bg-yellow-500/10 blur-[100px] -z-10 rounded-full"></div>
        
        <div className="max-w-4xl mx-auto text-center space-y-6">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-yellow-500/10 border border-yellow-500/20 text-yellow-400 text-sm font-medium animate-fade-in-up">
            <Lock className="w-4 h-4" /> 私密群組 • 名額有限
          </div>
          
          <h1 className="text-4xl md:text-6xl font-extrabold tracking-tight leading-tight text-white">
            每日只係 <span className="gold-gradient-text">$26</span><br/>
            換一個贏錢嘅機會，值唔值？
          </h1>
          
          <p className="text-lg text-gray-400 max-w-2xl mx-auto">
            與其每個月輸幾千蚊比馬會，不如用 $800 買一個贏錢嘅系統。
            想在這個月追返失去嘅？
          </p>

          <div className="pt-8">
            <Button href={STRIPE_PAYMENT_LINK} className="text-lg shadow-yellow-500/20 shadow-2xl">
              👉 立即獲取重心貼士
            </Button>
          </div>
        </div>
      </header>

      {/* Pain Points Section */}
      <PainPoints />

      {/* Value Proposition Section */}
      <section className="py-20 px-4 bg-dark-900 relative">
        <div className="max-w-6xl mx-auto grid md:grid-cols-3 gap-8">
          <FeatureBox 
            icon={<Target className="w-8 h-8 text-yellow-400" />}
            title="每日 1-2 場重心"
            desc="經過專業數據過濾，只選勝率最高的賽事 (Bankers)。重質不重量。"
          />
          <FeatureBox 
            icon={<Lock className="w-8 h-8 text-yellow-400" />}
            title="堅料內幕消息"
            desc="馬房落飛、球隊陣容第一手消息，早過莊家一步掌握先機。"
          />
          <FeatureBox 
            icon={<TrendingUp className="w-8 h-8 text-yellow-400" />}
            title="即場走地指導"
            desc="帶你避開假盤，精準捕捉入球時機，擴大盈利。"
          />
        </div>
      </section>

      {/* Pricing Section */}
      <section className="py-20 px-4 bg-dark-800">
        <div className="max-w-4xl mx-auto text-center mb-12">
          <h2 className="text-3xl font-bold text-white mb-4">數口好簡單</h2>
          <p className="text-gray-400">
            只要跟中我地一場重心，你個月費已經即時回本！<br/>
            之後嘅每一場，全部都係 <span className="text-emerald-400 font-bold">純利潤 (Net Profit)</span>。
          </p>
        </div>
        <PricingCard />
      </section>

      {/* Footer / Disclaimer */}
      <Disclaimer />

    </div>
  );
};

const FeatureBox: React.FC<{ icon: React.ReactNode, title: string, desc: string }> = ({ icon, title, desc }) => (
  <div className="bg-white/5 border border-white/10 p-6 rounded-2xl hover:bg-white/10 transition-colors duration-300">
    <div className="bg-yellow-500/10 w-16 h-16 rounded-xl flex items-center justify-center mb-4">
      {icon}
    </div>
    <h3 className="text-xl font-bold text-white mb-2">{title}</h3>
    <p className="text-gray-400 leading-relaxed">{desc}</p>
  </div>
);

export default App;
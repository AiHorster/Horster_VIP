import React from 'react';

interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'primary' | 'whatsapp' | 'outline';
  fullWidth?: boolean;
  href?: string;
}

export const Button: React.FC<ButtonProps> = ({ 
  children, 
  variant = 'primary', 
  fullWidth = false, 
  href,
  className = '',
  ...props 
}) => {
  const baseStyles = "inline-flex items-center justify-center px-6 py-4 text-lg font-bold rounded-xl transition-all duration-300 transform hover:scale-[1.02] shadow-lg active:scale-95";
  
  const variants = {
    primary: "bg-gradient-to-r from-yellow-400 to-yellow-600 text-black hover:shadow-yellow-500/20 border border-yellow-400/50",
    whatsapp: "bg-[#25D366] text-white hover:bg-[#20bd5a] hover:shadow-green-500/20",
    outline: "border-2 border-white/20 text-white hover:bg-white/10"
  };

  const widthClass = fullWidth ? "w-full" : "";
  const combinedClasses = `${baseStyles} ${variants[variant]} ${widthClass} ${className}`;

  if (href) {
    return (
      <a href={href} target="_blank" rel="noopener noreferrer" className={combinedClasses}>
        {children}
      </a>
    );
  }

  return (
    <button className={combinedClasses} {...props}>
      {children}
    </button>
  );
};
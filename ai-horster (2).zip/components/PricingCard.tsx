import React from 'react';
import { Check, ShieldCheck, CreditCard, Smartphone } from 'lucide-react';
import { Button } from './Button';
import { STRIPE_PAYMENT_LINK, WHATSAPP_LINK } from '../constants';

export const PricingCard: React.FC = () => {
  return (
    <div className="max-w-md mx-auto relative group">
      {/* Glowing Effect */}
      <div className="absolute -inset-1 bg-gradient-to-r from-yellow-600 to-yellow-400 rounded-2xl blur opacity-25 group-hover:opacity-50 transition duration-1000 group-hover:duration-200"></div>
      
      <div className="relative bg-dark-900 border border-yellow-500/30 rounded-2xl p-8 shadow-2xl">
        {/* Header */}
        <div className="text-center mb-8">
          <span className="bg-yellow-500/20 text-yellow-400 text-xs font-bold px-3 py-1 rounded-full uppercase tracking-wider">
            Limited Time Offer
          </span>
          <h3 className="text-4xl font-bold text-white mt-4 mb-2">
            VIP 尊貴會員
          </h3>
          <div className="flex justify-center items-baseline gap-1">
            <span className="text-5xl font-extrabold gold-gradient-text">$800</span>
            <span className="text-gray-400">/ 月</span>
          </div>
          <p className="text-gray-400 mt-2 text-sm">平均每日只需 $26 (平過食個下午茶)</p>
        </div>

        {/* Features */}
        <div className="space-y-4 mb-8">
          <FeatureRow text="每日 1-2 場重心 (Bankers) - 勝率最高" />
          <FeatureRow text="堅料內幕：馬房落飛、球隊陣容第一手消息" />
          <FeatureRow text="走地指導：帶你避開假盤，捉住入球時機" />
          <FeatureRow text="數口簡單：中一場重心即回本，之後全純利" />
        </div>

        {/* Payment Warning */}
        <div className="bg-red-500/10 border-2 border-red-500 p-4 rounded-xl mb-6">
          <p className="text-red-200 text-sm text-center font-medium">
            ⚠️ 付款時記得一定要填寫你的 <br/>
            <span className="text-white font-bold underline">WhatsApp 電話</span>
          </p>
        </div>

        {/* CTA Button */}
        <div className="space-y-4">
          <Button href={STRIPE_PAYMENT_LINK} fullWidth className="text-sm sm:text-lg md:text-xl animate-pulse px-2">
            👉 立即入會 (經 Stripe 安全支付)
          </Button>
          
          {/* Security Badges */}
          <div className="flex flex-col gap-3 pt-4 border-t border-gray-800">
             <p className="text-xs text-center text-gray-500">
               我們使用 Stripe 國際級支付系統，銀行級保安加密。<br/>
               支援 Apple Pay / 信用卡，資料絕對保密，安全放心！
             </p>
             <div className="flex justify-center gap-4 text-gray-400">
                <div className="flex items-center gap-1 text-xs">
                  <ShieldCheck className="w-4 h-4" /> SSL Encrypted
                </div>
                <div className="flex items-center gap-1 text-xs">
                  <CreditCard className="w-4 h-4" /> Credit Card
                </div>
                <div className="flex items-center gap-1 text-xs">
                  <Smartphone className="w-4 h-4" /> Apple Pay
                </div>
             </div>
          </div>
        </div>

        {/* Support Link */}
        <div className="mt-6 text-center">
          <p className="text-xs text-red-500 font-bold mb-2">
            付款後24小時內沒有收到入群通知？
          </p>
          <Button href={WHATSAPP_LINK} variant="whatsapp" fullWidth className="text-sm font-bold shadow-lg shadow-green-900/20">
            請立即點擊WhatsApp連結與助手溝通
          </Button>
        </div>
      </div>
    </div>
  );
};

const FeatureRow: React.FC<{ text: string }> = ({ text }) => (
  <div className="flex items-start gap-3">
    <div className="mt-1 bg-yellow-500/20 p-1 rounded-full">
      <Check className="w-3 h-3 text-yellow-400" />
    </div>
    <p className="text-gray-300 text-sm">{text}</p>
  </div>
);
import React from 'react';
import { XCircle, CheckCircle2, AlertTriangle } from 'lucide-react';

export const PainPoints: React.FC = () => {
  return (
    <section className="py-16 px-4 bg-dark-800">
      <div className="max-w-4xl mx-auto">
        <h2 className="text-3xl font-bold text-center mb-12 text-white">
          你有無試過？
        </h2>
        
        <div className="grid md:grid-cols-2 gap-8">
          {/* Pain Points */}
          <div className="bg-red-500/10 border border-red-500/20 rounded-2xl p-6 space-y-6">
            <h3 className="text-xl font-bold text-red-400 flex items-center gap-2 mb-6">
              <AlertTriangle className="w-6 h-6" />
              一般賭徒心態
            </h3>
            
            <ul className="space-y-4">
              <li className="flex items-start gap-3">
                <XCircle className="w-6 h-6 text-red-500 shrink-0 mt-1" />
                <p className="text-gray-300">亂買一通，一個週末輸幾千？</p>
              </li>
              <li className="flex items-start gap-3">
                <XCircle className="w-6 h-6 text-red-500 shrink-0 mt-1" />
                <p className="text-gray-300">贏粒糖，輸間廠，最後埋單總是負數？</p>
              </li>
              <li className="flex items-start gap-3">
                <XCircle className="w-6 h-6 text-red-500 shrink-0 mt-1" />
                <p className="text-gray-300">臨場心急追數，越追越深？</p>
              </li>
            </ul>
          </div>

          {/* Solution */}
          <div className="bg-emerald-500/10 border border-emerald-500/20 rounded-2xl p-6 space-y-6 relative overflow-hidden">
            <div className="absolute top-0 right-0 w-24 h-24 bg-emerald-500/20 blur-3xl -z-10"></div>
            
            <h3 className="text-xl font-bold text-emerald-400 flex items-center gap-2 mb-6">
              <CheckCircle2 className="w-6 h-6" />
              VIP 專業投資心態
            </h3>
            
            <p className="text-emerald-100/80 italic mb-4">
              其實賭錢係一種投資，你需要的是紀律同數據。
            </p>

            <ul className="space-y-4">
              <li className="flex items-start gap-3">
                <CheckCircle2 className="w-6 h-6 text-emerald-500 shrink-0 mt-1" />
                <p className="text-white font-medium">每日只係 $26，換一個贏錢嘅機會</p>
              </li>
              <li className="flex items-start gap-3">
                <CheckCircle2 className="w-6 h-6 text-emerald-500 shrink-0 mt-1" />
                <p className="text-white font-medium">嚴格資金管理，唔會盲目追數</p>
              </li>
              <li className="flex items-start gap-3">
                <CheckCircle2 className="w-6 h-6 text-emerald-500 shrink-0 mt-1" />
                <p className="text-white font-medium">數據過濾重心，提高勝率</p>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </section>
  );
};
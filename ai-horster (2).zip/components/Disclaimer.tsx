import React from 'react';

export const Disclaimer: React.FC = () => {
  return (
    <footer className="bg-black py-12 px-4 border-t border-gray-800">
      <div className="max-w-3xl mx-auto text-center space-y-4">
        <div className="p-4 bg-gray-900 rounded-lg border border-gray-800">
          <h4 className="text-white text-sm font-bold mb-2 tracking-wider uppercase border-b border-gray-700 pb-2 inline-block">重要聲明</h4>
          <p className="text-[10px] text-white leading-relaxed mt-2">
            ・請經由合法途徑 [香港賽馬會 (HKJC)] 投注 ・<br/>
            ・賭博有風險，過往成績不代表將來表現・<br/>
            本網站所有內容純屬資訊性質，並不涉及任何金錢賭博，特此聲明。<br/>
            本網資訊只適合十八歲或以上人士進入或觀看, 未滿十八歲人士不可參與馬會博彩活動。
          </p>
        </div>
        <p className="text-[10px] text-gray-700">
          &copy; {new Date().getFullYear()} Ai-Horster. All Rights Reserved.
        </p>
        
        {/* Visitor Counter Widget */}
        <div className="flex justify-center pt-6">
          <div className="elfsight-app-f45bf896-3184-4a19-866f-1d8adb3ab18d" data-elfsight-app-lazy></div>
        </div>
      </div>
    </footer>
  );
};